// Edit bilingual portfolio records here. Only add public, approved work links and media.
window.articles = [
  {
    url:'https://authory.com/MichelleYu/a/a5fb8ec0eeaea45e18a5ad2d412fceb2f',
    source:'News Writing · PDF', date:'5 Nov 2024', color:'#164f59',
    en:{title:'Toxic Waters: The Hidden Crisis of Algal Blooms in Australia',summary:'An investigative feature on the growing environmental and public-health threat posed by harmful algal blooms in Australia.'},
    zh:{title:'有毒水域：澳大利亚藻华危机的隐秘威胁',summary:'一篇调查性特稿，关注有害藻华对澳大利亚环境与公共健康构成的日益严峻的威胁。'}
  },
  {
    url:'https://www.mojonews.com.au/stop-the-silence-chants-in-melbourne-central-celebrations-on-the-day-before-international-womens-day-2024/',
    source:'MOJO News · Article', date:'28 Mar 2024', color:'#7e3e34',
    image:'https://storage.ghost.io/c/85/62/8562d330-2d04-4f73-8c6f-d726e69c29ea/content/images/2025/11/tzmgcO4TiYiUGpzBQG80.jpg',
    en:{title:'Rally Disrupts Culture of Silence on Gender Inequality',summary:'Reporting from a rally outside the State Library of Victoria addressing urgent issues affecting women.'},
    zh:{title:'集会打破性别不平等问题上的沉默文化',summary:'在维多利亚州立图书馆外进行现场报道，关注影响女性的紧迫议题。'}
  }
];

window.projects = [
  {
    id:'cologne', category:'interviews', cover:'spoga+gafa', color:'#2840cf',
    coverImage:'https://i.ytimg.com/vi/YlC5iEd1z2U/hqdefault.jpg',
    mediaItems:[
      {type:'youtube',id:'YlC5iEd1z2U',url:'https://youtu.be/YlC5iEd1z2U',en:'BBQ Trends at spoga+gafa 2026 | 77degree Onsite',zh:'spoga+gafa 2026 BBQ趋势｜77degree现场'},
      {type:'youtube',id:'eTH7_YFR23Q',url:'https://youtu.be/eTH7_YFR23Q',en:'Interview with Claudia Maurer, Director of spoga+gafa',zh:'采访spoga+gafa总监Claudia Maurer'},
      {type:'instagram',id:'DbaZEZ9FOET',url:'https://www.instagram.com/reel/DbaZEZ9FOET/',thumbnail:'assets/cologne/dreame.jpg',en:'Dreame & MOVA: Taking Smart Home Technology Outdoors',zh:'追觅与MOVA：智能家居技术走向户外'},
      {type:'instagram',id:'DacosM6kpNx',url:'https://www.instagram.com/reel/DacosM6kpNx/',thumbnail:'assets/cologne/ecovacs.jpg',en:'ECOVACS: From Indoor Cleaning to Smart Outdoor Maintenance',zh:'科沃斯：从室内清洁到智能户外维护'},
      {type:'instagram',id:'DaceUUdgEw-',url:'https://www.instagram.com/reel/DaceUUdgEw-/',thumbnail:'assets/cologne/roborock.jpg',en:'Roborock Brings Smart Cleaning to European Gardens',zh:'石头科技：将智能清洁带入欧洲花园'},
      {type:'instagram',id:'DaU2EowFHOb',url:'https://www.instagram.com/reel/DaU2EowFHOb/',thumbnail:'assets/cologne/garden.jpg',en:'Media Tour: Three Trends Shaping Garden Living',zh:'媒体导览：重塑花园生活的三大趋势'},
      {type:'instagram',id:'Dbaet32CGUS',url:'https://www.instagram.com/reel/Dbaet32CGUS/',thumbnail:'assets/cologne/parasol.jpg',en:'Media Tour: Outdoor Furniture & Parasol Solutions',zh:'媒体导览：户外家具与遮阳伞解决方案'}
    ],
    en:{title:'Reporting from Cologne',tag:'International reporting · English interviews',role:'On-site reporting lead · Interviewer',summary:'Company and policy interviews conducted across a three-day exhibition in Germany.',context:'Led on-site coverage at spoga+gafa, coordinating press tours, interview access, filming and publication with an editorial team in China.',actions:'Researched exhibitors and interviewees before the event, then personally interviewed Roborock, ECOVACS and Dreame. Adapted English questions to product demonstrations, booth information and interviewees’ answers, moving from product features to technology, overseas markets and brand positioning. Interviewed spoga+gafa Director Claudia Maurer about EU Digital Product Passports and their implications for Chinese companies entering Europe.',result:'Delivered bilingual coverage under tight exhibition deadlines. When schedules changed or brands did not reply, approached booths directly and arranged on-site interviews.',reflection:'Strong international reporting depends on preparation, but the interview becomes useful when the reporter can recognise a new angle and follow it in real time.'},
    zh:{title:'科隆现场：企业与政策专题采访',tag:'国际报道 · 英文采访',role:'现场报道负责人 · 采访记者',summary:'在德国三天展期内完成企业、市场与政策议题采访。',context:'主导spoga+gafa科隆展会现场报道，统筹媒体导览、采访邀约、拍摄与发布节点，并与国内编辑团队跨时区协作。',actions:'采访前研究企业参展重点及嘉宾职责；现场亲自采访石头科技、科沃斯和追觅，结合产品演示、展台信息和受访者回答调整英文提问，从产品延伸至技术差异、海外市场与品牌定位。采访展会负责人Claudia Maurer，围绕欧盟数字产品护照继续追问其对信息披露、合规准备及中国企业进入欧洲市场的影响。',result:'在展会紧凑时限内完成双语报道；遇到日程变化或品牌未回复时，主动前往展位协调临时采访，保证重点选题继续推进。',reflection:'国际现场采访需要充分准备，也需要记者在对话中识别新角度，并即时完成有效追问。'}
  },
  {
    id:'industry', category:'interviews', cover:'Across six markets', color:'#e8edf3', ink:'#203449',
    coverImage:'https://i.ytimg.com/vi/WwxH_VVCgVE/hqdefault.jpg',
    mediaItems:[
      {type:'youtube',id:'WwxH_VVCgVE',url:'https://youtu.be/WwxH_VVCgVE',en:'King Koil global distributor interviews',zh:'金可儿全球经销商专题采访'}
    ],
    en:{title:'King Koil: six markets, one interview project',tag:'International markets · On-site interview',role:'Researcher · English-language interviewer · Editor',summary:'Guest profiling, market research and flexible follow-up questions across six regional perspectives.',context:'A thematic interview project with global distributor representatives from six markets, examining how one international brand is interpreted and operated locally.',actions:'Researched each guest’s company, market, channels, manufacturing context and decision-making role. Built differentiated guest profiles and an interview framework before filming. During the English interviews, followed the guests’ answers and event context rather than relying mechanically on prepared questions, asking for concrete examples from products, stores, hotel partnerships and supply chains.',result:'Compared six perspectives after the interviews and identified common ground and differences between global brand consistency and regional localisation.',reflection:'Background research creates the map; attentive listening determines which path produces the strongest story.'},
    zh:{title:'金可儿：六个市场的专题采访项目',tag:'国际市场 · 现场英文采访',role:'前期研究 · 英文采访 · 内容编辑',summary:'从嘉宾画像到现场追问，比较六个区域市场的品牌实践。',context:'围绕金可儿全球经销商开展专题采访，观察同一国际品牌在六个市场中的消费认知、渠道结构与本地化实践。',actions:'采访前逐一研究嘉宾所在企业、当地市场、酒店与零售渠道、制造能力及本人决策职责，建立差异化嘉宾画像和采访框架。现场根据嘉宾回答、活动环节与市场差异灵活补充英文追问，引导受访者以产品、门店、酒店合作或供应链案例说明判断。',result:'采访后交叉梳理六位嘉宾观点，提炼全球品牌一致性与区域本地化之间的共性和差异。',reflection:'背景研究提供采访地图，现场倾听决定记者应该沿哪条线索继续追问。'}
  },
  {
    id:'cbd',category:'projects',cover:'The countdown',color:'#162f32',
    en:{title:'A countdown built around a brand',tag:'CBD Guangzhou 2026 · Planning',role:'Video concept & content planning',summary:'A connected series of countdown concepts for an exhibition campaign.',context:'Develop a video plan for the 2026 China (Guangzhou) International Building Decoration Fair.',actions:'Planned five countdown video concepts and an opening video concept, considering the messaging sequence, content structure and review milestones.',result:'A campaign planning project. This portfolio does not claim that every proposed video was produced or published.',reflection:'Each instalment needs a distinct purpose within a coherent communication plan.'},
    zh:{title:'将倒计时变成系列品牌表达',tag:'2026广州建博会 · 方案策划',role:'视频概念与内容策划',summary:'围绕展会传播目标设计连续、有层次的倒计时内容。',context:'为2026广州建博会制定倒计时及开幕视频方案。',actions:'规划五条倒计时视频和一条开幕视频的概念，考虑信息节奏、内容结构与审核节点。',result:'这里展示的是策划实践，不将全部方案描述为已制作或已发布成品。',reflection:'系列内容中的每一期，都需要在整体传播计划中承担清晰任务。'}
  },
  {
    id:'milan',category:'bilingual',cover:'Across languages',color:'#293547',
    en:{title:'Design stories, translated with context',tag:'Milan / MIFF · Editorial',role:'Editorial contributor · Bilingual editor',summary:'Adapting furnishings and design content across languages and audiences.',context:'Contributed to Milan-related brand stories and MIFF editorial work.',actions:'Worked on LAGO, TRÉCA and Trone content alongside bilingual editing for MIFF, focusing on clarity, brand context and audience-appropriate expression.',result:'Editorial contribution, not a claim of leading on-site Milan coverage.',reflection:'Localisation requires decisions about context and emphasis, not only replacing words.'},
    zh:{title:'让设计故事在不同语言中成立',tag:'米兰 / MIFF · 编辑',role:'编辑贡献者 · 双语编辑',summary:'跨语言、跨受众调整家居与设计内容的表达。',context:'参与米兰相关品牌报道与MIFF编辑工作。',actions:'参与LAGO、TRÉCA、Trone相关内容，并承担MIFF双语编辑工作，关注表达清晰度、品牌背景与受众理解。',result:'此处标注为编辑贡献，不描述为米兰现场主导报道。',reflection:'本地化不仅是替换语言，还涉及背景补充与信息重点判断。'}
  },
  {
    id:'mojo',category:'journalism',cover:'Everyday stories',color:'#d9e5df',ink:'#1a3831',
    coverImage:'https://i.ytimg.com/vi/lKJzqCVp8L0/hqdefault.jpg',
    mediaItems:[
      {type:'youtube',id:'lKJzqCVp8L0',url:'https://www.youtube.com/watch?v=lKJzqCVp8L0',en:'Federal Election 2025: Supermarket Duopoly',zh:'2025联邦大选：澳大利亚超市双寡头'},
      {type:'youtube',id:'c13dQafrAfA',url:'https://www.youtube.com/watch?v=c13dQafrAfA&t=1s',en:'The Balancing Act of a Monash Student-Athlete',zh:'莫纳什学生运动员的平衡之道'},
      {type:'youtube',id:'K3pe5ACVq8o',url:'https://www.youtube.com/watch?v=K3pe5ACVq8o',en:'Breaking barriers to economic equality on International Women’s Day',zh:'国际妇女节：打破经济平等的障碍'},
      {type:'youtube',id:'cwSfpIrVZIQ',url:'https://www.youtube.com/watch?v=cwSfpIrVZIQ',en:'MOJO News Federal Election 2025 live broadcast',zh:'MOJO News 2025联邦大选直播'}
    ],
    en:{title:'Italy and Australia, through the supermarket',tag:'MOJO · Student journalism',role:'Reporter · Video producer',summary:'A report on supermarket competition, affordability and consumer experience.',context:'A student journalism project developed for the 2025 Australian federal election coverage.',actions:'Examined Coles and Woolworths’ market dominance, grocery prices and promotional practices using ACCC material, public-health research and consumer interviews, including field interviews in northern Italy.',result:'Connected market structure with everyday affordability and food choices within the available evidence.',reflection:'Everyday shopping can reveal how competition, regulation and public health meet in consumers’ lives.'},
    zh:{title:'从超市看竞争、价格与消费者选择',tag:'MOJO · 新闻报道',role:'记者 · 视频制作',summary:'从澳大利亚超市双寡头切入生活成本与消费者体验。',context:'为2025年澳大利亚联邦选举报道制作的学生新闻项目。',actions:'结合ACCC资料、公共健康研究与消费者采访，研究Coles和Woolworths的市场主导地位、食品价格与促销争议，并在意大利北部实地采访购物者。',result:'在现有证据范围内，将市场结构与食品可负担性和消费者选择联系起来。',reflection:'日常购物场景能够呈现竞争、监管与公共健康如何共同影响消费者。'}
  },
  {
    id:'struggle',category:'journalism',cover:'The Struggle',color:'#2a2633',
    coverImage:'https://i.ytimg.com/vi/YUEyGeb4TFA/hqdefault.jpg',
    mediaItems:[
      {type:'youtube',id:'YUEyGeb4TFA',url:'https://www.youtube.com/watch?v=YUEyGeb4TFA',en:'Channel 7, War Crimes and Drunken Chiros – Full Episode',zh:'Channel 7、战争罪与醉酒脊医 – 完整节目'},
      {type:'youtube',id:'S9HzqbX4Qqw',start:1245,url:'https://www.youtube.com/watch?v=S9HzqbX4Qqw&t=1245s',en:'Brats, Virgins and the Plight of Minors – Full Episode',zh:'Brats、Virgins与未成年人困境 – 完整节目'},
      {type:'youtube',id:'N7oS0vWp2nY',url:'https://www.youtube.com/watch?v=N7oS0vWp2nY',en:'The Death of Music Festivals, Housing, and Bruce Lehrmann – Full Episode',zh:'音乐节、住房与Bruce Lehrmann – 完整节目'}
    ],
    en:{title:'The Struggle: television news and satire',tag:'Channel 31 · Television production',role:'Journalist · Writer · Production contributor',summary:'Three full television episodes covering Australian and international current affairs.',context:'Contributed to The Struggle, a Channel 31 television programme combining current-affairs reporting, writing and satirical presentation.',actions:'Supported research, writing, filming and production across stories involving Australian public affairs and international news, helping translate complex topics into concise broadcast segments.',result:'Contributed to three full episodes published on YouTube and broadcast through Channel 31.',reflection:'Television reporting requires accuracy and structure, while format and tone determine whether an audience stays with the story.'},
    zh:{title:'The Struggle：电视新闻与讽刺节目',tag:'Channel 31 · 电视制作',role:'记者 · 撰稿人 · 节目制作参与者',summary:'参与三期完整电视节目，涉及澳大利亚及国际公共议题。',context:'参与Channel 31电视节目The Struggle，将时事报道、新闻写作与讽刺表达结合。',actions:'参与澳大利亚公共议题及国际新闻内容的研究、撰写、拍摄与制作，协助把复杂议题转化为适合电视播出的清晰段落。',result:'参与的三期完整节目已在YouTube发布，并通过Channel 31播出。',reflection:'电视报道需要事实与结构，节目形式和语气则决定观众是否愿意继续理解议题。'}
  },
  {
    id:'hobart',category:'journalism',cover:'Hobart',color:'#354643',
    en:{title:'Climate reporting in Hobart',tag:'Australia · Field reporting',role:'Journalism project contributor',summary:'On-site climate reporting from Mount Wellington during the 2025 election period.',context:'A separate Australian journalism project exploring environmental issues in the context of the federal election.',actions:'Contributed on-site reporting from Mount Wellington in Hobart and connected the location with the wider political discussion.',result:'The project is included as a reporting overview; publication evidence will be added after verification.',reflection:'Field reporting is strongest when the location adds evidence and context.'},
    zh:{title:'霍巴特气候与选举议题报道',tag:'澳大利亚 · 现场报道',role:'新闻项目参与者',summary:'在2025年选举背景下从惠灵顿山进行气候议题现场报道。',context:'一项独立的澳大利亚新闻项目，探讨环境议题与联邦选举的关系。',actions:'从霍巴特惠灵顿山参与现场报道，将具体地点与更广泛的政治讨论相连接。',result:'目前作为报道项目概览，发布证据将在核实后补充。',reflection:'现场报道的价值，在于地点能够提供证据和背景。'}
  }
];
