let language = 'en';
let filter = 'all';

const categories = {
  all: ['All work', '全部作品', 'The strongest reporting, interviews and editorial work, ordered by relevance.', '按代表性与完成度排列的报道、采访和编辑作品。'],
  featured: ['Featured', '精选视频', 'Selected field reporting and television work.', '精选现场报道与电视节目。'],
  interviews: ['Interviews', '专题采访', 'English-language company and industry interviews.', '企业与产业相关英文专题采访。'],
  journalism: ['News & TV', '新闻与电视', 'Video journalism, live broadcast work and field coverage.', '视频新闻、直播节目与现场报道。'],
  articles: ['Articles', '文章', 'Published reporting and long-form writing.', '已发表的新闻报道与深度写作。']
};

const showcasePlan = [
  {project:'cologne', media:0, category:'featured', summary:{en:'Field report on the products and brands shaping outdoor cooking at spoga+gafa 2026.',zh:'从spoga+gafa 2026现场报道户外烹饪领域的产品与品牌趋势。'}, role:{en:'On-site reporter · Video producer',zh:'现场记者 · 视频制作'}, context:{en:'A field report from the exhibition’s BBQ area, featuring Campingaz, Enders, Petromax and Gaumencunst.',zh:'在展会BBQ区域完成现场报道，涉及Campingaz、Enders、Petromax与Gaumencunst。'}, contribution:{en:'Researched the brands, gathered product demonstrations and exhibition footage, and structured the story around portable grilling, family outdoor cooking and modular fire systems.',zh:'研究参展品牌，采集产品演示与展会画面，并围绕便携烧烤、家庭户外烹饪与模块化火炉组织报道。'}, outcome:{en:'Produced a concise bilingual video that translated exhibition-floor observations into an accessible industry trend story.',zh:'完成一条双语视频，将展会现场观察转化为清晰易懂的行业趋势报道。'}},
  {project:'struggle', media:0, category:'featured', summary:{en:'A full Channel 31 episode combining current affairs, television writing and satire.',zh:'结合时事报道、电视写作与讽刺表达的Channel 31完整节目。'}, role:{en:'Journalist · Writer · Production contributor',zh:'记者 · 撰稿人 · 节目制作参与者'}, context:{en:'One of three full episodes from The Struggle, a Channel 31 programme presenting multiple current-affairs segments.',zh:'The Struggle在Channel 31播出的三期完整节目之一，由多个时事新闻段落组成。'}, contribution:{en:'Contributed to research, script development, filming and editing across selected news segments; the portfolio does not attribute every segment in the full episode to me.',zh:'参与部分新闻段落的资料研究、脚本撰写、拍摄与编辑；作品集不将整期所有内容都归为本人制作。'}, outcome:{en:'The completed episode was broadcast on Channel 31 and published on YouTube.',zh:'完整节目在Channel 31播出并发布于YouTube。'}},
  {project:'struggle', media:1, category:'featured', summary:{en:'A full episode from The Struggle’s fourteenth season.',zh:'The Struggle第十四季完整节目。'}, role:{en:'Journalist · Writer · Production contributor',zh:'记者 · 撰稿人 · 节目制作参与者'}, context:{en:'A multi-story current-affairs and satire programme produced for community television.',zh:'为社区电视制作的多议题时事与讽刺节目。'}, contribution:{en:'Supported research, writing, filming and post-production for selected segments while working within the wider programme team.',zh:'在节目团队中参与部分段落的研究、撰写、拍摄与后期制作。'}, outcome:{en:'Contributed material formed part of the finished Channel 31 episode and its online release.',zh:'参与制作的内容被纳入Channel 31完整节目及其线上版本。'}},
  {project:'struggle', media:2, category:'featured', summary:{en:'A full episode covering Australian culture, housing and public affairs.',zh:'涉及澳大利亚文化、住房与公共议题的完整节目。'}, role:{en:'Journalist · Writer · Production contributor',zh:'记者 · 撰稿人 · 节目制作参与者'}, context:{en:'A full The Struggle episode containing several independently developed news and commentary segments.',zh:'The Struggle完整节目，由多条分别策划的新闻与评论段落组成。'}, contribution:{en:'Contributed newsroom research, broadcast writing, filming and editing to selected segments rather than claiming authorship of the entire episode.',zh:'参与部分段落的新闻研究、电视稿件撰写、拍摄和编辑，不将整期节目表述为个人独立作品。'}, outcome:{en:'The collaborative programme was broadcast on Channel 31 and made available on YouTube.',zh:'该团队节目在Channel 31播出并上线YouTube。'}},
  {project:'mojo', media:0, category:'featured', summary:{en:'An investigation into supermarket concentration and Australia’s cost-of-living crisis.',zh:'关于澳大利亚超市集中度与生活成本危机的调查报道。'}, role:{en:'Independent reporter · Video producer',zh:'独立记者 · 视频制作'}, context:{en:'Produced for MOJO News’s 2025 Australian federal election coverage, examining Coles and Woolworths’ market dominance, prices and promotional practices.',zh:'为MOJO News的2025年澳大利亚联邦选举报道制作，调查Coles与Woolworths的市场主导地位、食品价格及促销争议。'}, contribution:{en:'Researched ACCC material and public-health evidence, interviewed consumers, and filmed shoppers in northern Italy to compare affordability and shopping experiences across Australia and Italy.',zh:'研究ACCC资料与公共健康证据，采访消费者，并在意大利北部拍摄采访，对比澳大利亚与意大利的食品可负担性及购物体验。'}, outcome:{en:'Independently delivered the reporting, interviews and video production for the published election feature.',zh:'独立完成该选举专题的报道、采访与视频制作并公开发布。'}},

  {project:'cologne', media:1, category:'interviews', summary:{en:'Interview with Claudia Maurer on spoga+gafa and the EU Digital Product Passport.',zh:'采访Claudia Maurer，讨论spoga+gafa与欧盟数字产品护照。'}, role:{en:'Interviewer · Policy researcher',zh:'采访记者 · 政策研究'}, context:{en:'An interview with Claudia Maurer, Director of spoga+gafa, connecting exhibition strategy with emerging EU product-information requirements.',zh:'采访spoga+gafa总监Claudia Maurer，将展会战略与欧盟新兴产品信息要求联系起来。'}, contribution:{en:'Prepared background research and conducted the English interview, following up on product disclosure, compliance preparation and the implications for Chinese companies entering Europe.',zh:'完成前期背景研究并开展英文采访，继续追问产品信息披露、合规准备及其对中国企业进入欧洲市场的影响。'}, outcome:{en:'Produced a bilingual interview that translated a technical policy issue into practical questions for exporting companies.',zh:'完成双语专题采访，将技术性政策议题转化为出海企业可理解的实际问题。'}},
  {project:'industry', media:0, category:'interviews', summary:{en:'Interviews with King Koil distributors across six international markets.',zh:'采访来自六个国际市场的金可儿经销商。'}, role:{en:'Researcher · English-language interviewer · Editor',zh:'前期研究 · 英文采访 · 内容编辑'}, context:{en:'A comparative interview project with King Koil representatives from six markets.',zh:'面向六个市场金可儿代表开展的比较型专题采访。'}, contribution:{en:'Profiled each guest and market before filming, then adapted English follow-up questions to examples involving retail, hotels, manufacturing and supply chains.',zh:'采访前研究每位嘉宾及其市场，现场根据回答灵活追问零售、酒店合作、制造与供应链案例。'}, outcome:{en:'Compared the six perspectives to identify differences between global brand consistency and regional localisation.',zh:'交叉比较六位受访者观点，提炼全球品牌一致性与区域本地化之间的差异。'}},
  {project:'cologne', media:2, category:'interviews', summary:{en:'Dreame and MOVA discuss how smart-home technology is expanding into outdoor categories.',zh:'追觅与MOVA讲述智能家居技术如何延伸至户外品类。'}, role:{en:'On-site English interviewer · Reporter',zh:'现场英文采访记者'}, context:{en:'An exhibition-floor interview focused on robotic lawn mowers and the brands’ wider outdoor technology strategy.',zh:'展会现场采访，关注割草机器人及品牌更广泛的户外科技布局。'}, contribution:{en:'Interviewed the brand representative in English and moved from product configurations to user needs, garden care, power tools and overseas category expansion.',zh:'用英文采访品牌代表，从产品配置延伸至用户需求、花园养护、电动工具与海外品类拓展。'}, outcome:{en:'Published as a bilingual Instagram Reel for an international industry audience.',zh:'制作成面向国际行业受众的双语Instagram短视频。'}},
  {project:'cologne', media:3, category:'interviews', summary:{en:'ECOVACS explains how home robotics is moving from indoor cleaning to outdoor maintenance.',zh:'科沃斯讲述家用机器人如何从室内清洁走向户外维护。'}, role:{en:'On-site English interviewer · Reporter',zh:'现场英文采访记者'}, context:{en:'An on-site interview featuring the GOAT T Series lawn-care robots and Ultramarine P1 pool-cleaning system.',zh:'现场采访涉及GOAT T系列割草机器人与Ultramarine P1泳池清洁系统。'}, contribution:{en:'Conducted the English interview and used the product demonstrations to ask how robotic systems address more complex lawn and pool-care scenarios.',zh:'开展英文采访，并结合产品演示追问机器人系统如何应对更复杂的草坪与泳池维护场景。'}, outcome:{en:'Delivered a focused bilingual Reel linking individual products to the wider smart-outdoor-living trend.',zh:'完成一条聚焦明确的双语短视频，将具体产品与智能户外生活趋势联系起来。'}},
  {project:'cologne', media:4, category:'interviews', summary:{en:'Roborock discusses its first appearance in Cologne and the extension of smart cleaning into gardens.',zh:'石头科技讲述首次亮相科隆及智能清洁向花园场景延伸。'}, role:{en:'On-site English interviewer · Reporter',zh:'现场英文采访记者'}, context:{en:'An interview with Roborock’s Head of Marketing about robotic lawn mowers and entry into the European outdoor-living market.',zh:'采访石头科技市场负责人，关注割草机器人及品牌进入欧洲户外生活市场。'}, contribution:{en:'Conducted the English interview and followed up on binocular vision, radar mapping, obstacle avoidance and the brand’s outdoor-market positioning.',zh:'开展英文采访，围绕双目视觉、雷达建图、避障技术与品牌户外市场定位继续追问。'}, outcome:{en:'Produced a bilingual Reel presenting the technology and market context without reducing the story to a product demonstration.',zh:'制作双语短视频，在产品演示之外补充技术与市场背景。'}},

  {project:'mojo', media:1, category:'journalism', summary:{en:'An independently produced profile of Monash student-athlete Olivia McMahon.',zh:'独立制作的莫纳什大学学生运动员Olivia McMahon人物专题。'}, role:{en:'Independent reporter · Interviewer · Video producer',zh:'独立记者 · 采访记者 · 视频制作'}, context:{en:'After leading Team Monash to six medals at the 2024 UniSport National Athletics Championships, Olivia McMahon returned to university study and assessment deadlines.',zh:'Olivia McMahon带领Team Monash在2024年UniSport全国田径锦标赛获得六枚奖牌后，仍需回到大学完成学习与作业任务。'}, contribution:{en:'Developed the profile angle, conducted an in-depth interview, and independently produced the video around the practical and personal balance between elite competition and academic study.',zh:'确定人物特写角度，开展深度采访，并独立完成视频制作，呈现高水平竞技与大学学业之间的现实平衡。'}, outcome:{en:'Published by MOJO News as a focused student-athlete profile.',zh:'作为独立的学生运动员人物专题由MOJO News发布。'}},
  {project:'mojo', media:2, category:'journalism', summary:{en:'Field reporting on gender inequality during International Women’s Day events in Melbourne.',zh:'围绕墨尔本国际妇女节活动进行性别不平等议题现场报道。'}, role:{en:'Reporting lead · Camera · Video editor · Article writer',zh:'报道主导 · 拍摄 · 视频编辑 · 文章撰稿'}, context:{en:'A team report from International Women’s Day events and a rally outside the State Library of Victoria in 2024.',zh:'报道2024年国际妇女节活动及维多利亚州立图书馆外的集会。'}, contribution:{en:'Led production, filming and editing with the reporting team, conducted field interviews and wrote the accompanying digital article from the event material.',zh:'与报道团队合作主导制作、拍摄与编辑，完成现场采访，并根据活动素材撰写配套数字新闻文章。'}, outcome:{en:'Delivered both a video news report and a published MOJO News article on the issues raised by participants.',zh:'完成视频新闻与MOJO News配套文章，呈现参与者提出的女性权益议题。'}},
  {project:'mojo', media:3, category:'journalism', summary:{en:'Participation in MOJO News’s live coverage of the 2025 Australian federal election.',zh:'参与MOJO News 2025年澳大利亚联邦大选直播。'}, role:{en:'Deputy TV Broadcast Editor · Live broadcast contributor',zh:'电视播报副编辑 · 直播参与者'}, context:{en:'MOJO News’s live television coverage of the 2025 Australian federal election.',zh:'MOJO News对2025年澳大利亚联邦大选进行的电视直播报道。'}, contribution:{en:'Supported the live broadcast workflow in a deputy editorial capacity and contributed to the newsroom’s election coverage; this was a collaborative live production, not an independently produced feature.',zh:'以电视播报副编辑身份支持直播流程并参与编辑部选举报道；该作品属于团队直播制作，并非个人独立专题。'}, outcome:{en:'Contributed to the completed live programme published by MOJO News.',zh:'参与完成并发布MOJO News联邦大选直播节目。'}},
  {project:'cologne', media:5, category:'journalism', summary:{en:'Media tour on weather-resistant design, sustainable materials and flexible garden spaces.',zh:'围绕耐候设计、可持续材料与灵活花园空间展开的媒体导览。'}, role:{en:'On-site reporter · Media-tour video producer',zh:'现场记者 · 媒体导览视频制作'}, context:{en:'A garden-living media tour featuring outdoor solutions from Keter, Capi Europe and Groupe EDA.',zh:'花园生活主题媒体导览，涉及Keter、Capi Europe与Groupe EDA的户外解决方案。'}, contribution:{en:'Selected and organised examples from storage, planters and balcony or patio use, translating a fast-moving press tour into a structured bilingual trend story.',zh:'从收纳、花盆以及阳台和庭院应用中筛选案例，将节奏紧凑的媒体导览整理成结构清晰的双语趋势报道。'}, outcome:{en:'Published as an Instagram Reel showing how practical design is reshaping contemporary garden living.',zh:'以Instagram短视频发布，呈现实用设计如何重塑当代花园生活。'}},
  {project:'cologne', media:6, category:'journalism', summary:{en:'Media tour examining outdoor furniture, shading systems and sustainable materials.',zh:'关注户外家具、遮阳系统与可持续材料的媒体导览。'}, role:{en:'On-site reporter · Media-tour video producer',zh:'现场记者 · 媒体导览视频制作'}, context:{en:'A press tour featuring Doppler, 4 Seasons Outdoor and KETTLER at spoga+gafa 2026.',zh:'spoga+gafa 2026媒体导览，涉及Doppler、4 Seasons Outdoor与KETTLER。'}, contribution:{en:'Captured the tour and structured the video around flexible shading, handwoven furniture, comfort and material sustainability.',zh:'采集导览现场素材，并围绕灵活遮阳、手工编织家具、舒适性与材料可持续性组织视频。'}, outcome:{en:'Produced a bilingual Reel connecting individual brand examples with broader outdoor-living needs.',zh:'制作双语短视频，将品牌案例与更广泛的户外生活需求联系起来。'}}
];

const projectMap = Object.fromEntries(projects.map(project => [project.id, project]));
const grid = document.querySelector('#grid');
const dialog = document.querySelector('#detail');

function node(tag, text, cls) {
  const element = document.createElement(tag);
  element.textContent = text;
  if (cls) element.className = cls;
  return element;
}

function mediaThumbnail(item) {
  if (item.thumbnail) return item.thumbnail;
  if (item.type === 'youtube') return `https://i.ytimg.com/vi/${item.id}/hqdefault.jpg`;
  return null;
}

function render() {
  document.documentElement.lang = language === 'en' ? 'en' : 'zh-CN';
  document.querySelectorAll('[data-en]').forEach(element => { element.textContent = element.dataset[language]; });
  document.querySelector('#language').textContent = language === 'en' ? '中文' : 'EN';
  document.querySelector('#language').setAttribute('aria-label', language === 'en' ? 'Switch to Chinese' : 'Switch to English');
  document.querySelector('#close').setAttribute('aria-label', language === 'en' ? 'Close work' : '关闭作品');

  const active = categories[filter];
  document.querySelector('#collection-title').textContent = active[language === 'en' ? 0 : 1];
  document.querySelector('#collection-description').textContent = active[language === 'en' ? 2 : 3];

  const filters = document.querySelector('.filters');
  filters.replaceChildren();
  Object.entries(categories).forEach(([key, names]) => {
    const button = node('button', names[language === 'en' ? 0 : 1]);
    button.setAttribute('aria-pressed', key === filter);
    button.onclick = () => { filter = key; render(); };
    filters.append(button);
  });

  grid.replaceChildren();
  showcasePlan.filter(item => filter === 'all' || item.category === filter).forEach((entry, index) => {
    grid.append(buildVideoCard(entry, index));
  });
  if (filter === 'all' || filter === 'articles') {
    articles.forEach(article => grid.append(buildArticleCard(article)));
  }
}

function buildVideoCard(entry, index) {
  const project = projectMap[entry.project];
  const item = project.mediaItems[entry.media];
  const title = item[language];
  const button = node('button', '', `card video-card ${entry.category === 'featured' ? 'featured-card' : ''}`);
  button.setAttribute('aria-label', (language === 'en' ? 'Open video: ' : '打开视频：') + title);
  const cover = node('div', '', 'cover cover-photo');
  const thumbnail = mediaThumbnail(item);
  if (thumbnail) {
    const image = document.createElement('img');
    image.src = thumbnail;
    image.alt = title;
    image.loading = 'lazy';
    cover.append(image);
  } else {
    cover.classList.add('instagram-cover');
    cover.append(node('strong', 'Instagram Reel'));
  }
  cover.append(node('span', item.type === 'youtube' ? 'WATCH VIDEO' : 'WATCH REEL', 'media-badge'));
  const body = node('div', '', 'card-body');
  const categoryName = categories[entry.category][language === 'en' ? 0 : 1];
  body.append(node('span', categoryName, 'tag'), node('h3', title), node('p', entry.summary[language]), node('div', entry.role[language], 'role'));
  button.append(cover, body);
  button.onclick = () => openVideo(entry);
  return button;
}

function buildArticleCard(article) {
  const data = article[language];
  const link = node('a', '', 'card article-card');
  link.href = article.url;
  link.target = '_blank';
  link.rel = 'noopener';
  link.setAttribute('aria-label', (language === 'en' ? 'Read article: ' : '阅读文章：') + data.title);
  const cover = node('div', '', 'cover');
  if (article.image) {
    cover.classList.add('cover-photo');
    const image = document.createElement('img');
    image.src = article.image;
    image.alt = data.title;
    image.loading = 'lazy';
    cover.append(image);
  } else {
    cover.style.setProperty('--cover', article.color);
    cover.append(node('span', language === 'en' ? 'LONG-FORM REPORTING' : '深度报道', 'index'), node('strong', 'Toxic Waters'));
  }
  const body = node('div', '', 'card-body');
  body.append(node('span', categories.articles[language === 'en' ? 0 : 1], 'tag'), node('h3', data.title), node('p', data.summary), node('div', `${article.source} · ${article.date} ↗`, 'role'));
  link.append(cover, body);
  return link;
}

function buildPlayer(item) {
  const gallery = node('section', '', 'media-gallery single-media');
  const player = node('div', '', 'media-player');
  const frame = document.createElement('iframe');
  frame.title = item[language];
  frame.loading = 'eager';
  frame.allowFullscreen = true;
  frame.referrerPolicy = 'strict-origin-when-cross-origin';
  if (item.type === 'youtube') {
    frame.src = `https://www.youtube-nocookie.com/embed/${item.id}?rel=0${item.start ? `&start=${item.start}` : ''}`;
    frame.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
  } else {
    frame.src = `https://www.instagram.com/reel/${item.id}/embed/`;
    frame.allow = 'autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share';
  }
  const caption = node('div', '', 'media-caption');
  caption.append(node('strong', item[language]));
  const link = node('a', language === 'en' ? `Open on ${item.type === 'youtube' ? 'YouTube' : 'Instagram'} ↗` : `在${item.type === 'youtube' ? 'YouTube' : 'Instagram'}打开 ↗`);
  link.href = item.url;
  link.target = '_blank';
  link.rel = 'noopener';
  caption.append(link);
  player.append(frame, caption);
  gallery.append(player);
  return gallery;
}

function addVideoDetails(content, entry) {
  const labels = language === 'en' ? ['Story context', 'My contribution', 'Outcome & scope'] : ['报道背景', '我的贡献', '结果与职责边界'];
  ['context', 'contribution', 'outcome'].forEach((key, index) => content.append(node('h3', labels[index]), node('p', entry[key][language])));
}

function openVideo(entry) {
  const project = projectMap[entry.project];
  const item = project.mediaItems[entry.media];
  const content = document.querySelector('#detail-content');
  content.replaceChildren(node('span', categories[entry.category][language === 'en' ? 0 : 1], 'tag'), node('h2', item[language]), node('p', entry.role[language], 'role'), buildPlayer(item));
  addVideoDetails(content, entry);
  dialog.showModal();
}

document.querySelector('#language').onclick = () => { language = language === 'en' ? 'zh' : 'en'; render(); };
document.querySelector('#close').onclick = () => dialog.close();
dialog.addEventListener('close', () => {
  document.querySelectorAll('#detail iframe').forEach(frame => { frame.src = 'about:blank'; });
});
dialog.addEventListener('click', event => {
  if (event.target === dialog) {
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
  }
});
render();
